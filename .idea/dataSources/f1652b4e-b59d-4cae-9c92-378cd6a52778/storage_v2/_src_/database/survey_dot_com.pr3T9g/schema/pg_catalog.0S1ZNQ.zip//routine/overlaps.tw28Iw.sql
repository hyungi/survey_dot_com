CREATE FUNCTION "overlaps"(time without time zone, interval, time without time zone, interval)
  RETURNS boolean
IMMUTABLE
PARALLEL SAFE
COST 1
LANGUAGE SQL
AS $$
select ($1, ($1 + $2)) overlaps ($3, ($3 + $4))
$$;

